//
//  Keys.swift
//  pagination-demo
//
//  Created by mohamed hussein on 2/13/20.
//  Copyright © 2020 mohamed hussein. All rights reserved.
//

import Foundation

enum StorageKeys: String {
    case tags = "tags"
    case items = "items"

}


