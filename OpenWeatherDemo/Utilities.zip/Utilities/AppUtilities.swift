//
//  AppUtilities.swift
//  MenuApp
//
//  Created by mohamed hussein on 2/13/20.
//  Copyright © 2020 mohamed hussein. All rights reserved.
//

import Foundation

class AppUtilities {
    
    static let shared = AppUtilities()
   
    
    private init() {}
    
   
}
